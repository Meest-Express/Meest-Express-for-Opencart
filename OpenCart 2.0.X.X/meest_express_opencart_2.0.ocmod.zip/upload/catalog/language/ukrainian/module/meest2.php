<?php
// Heading
$_['heading_title'] = 'Meest Express';

// Text
$_['text_module'] = 'Модулі';
$_['text_success'] = 'Успішно: Ви змінили модуль Meest Express!';
$_['text_edit'] = 'Редагувати модуль Meest Express';

// Entry
$_['entry_status'] = 'Статус';

// Error
$_['error_permission'] = 'Попередження: У вас немає прав для зміни модуля Meest Express!';
