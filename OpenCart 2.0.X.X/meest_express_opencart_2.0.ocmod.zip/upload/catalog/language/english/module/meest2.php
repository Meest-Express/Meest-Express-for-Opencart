<?php
// Heading
$_['heading_title'] = 'Meest Express';

// Text
$_['text_module'] = 'Modules';
$_['text_success'] = 'Success: You have modified Meest Express module!';
$_['text_edit'] = 'Edit Meest Express Module';

// Entry
$_['entry_status'] = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Meest Express module!';
