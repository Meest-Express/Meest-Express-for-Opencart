<?php
// Heading
$_['heading_title'] = 'Meest Express';

// Text
$_['text_module'] = 'Модули';
$_['text_success'] = 'Успешно: Вы изменили модуль Meest Express!';
$_['text_edit'] = 'Редактировать модуль Meest Express';

// Entry
$_['entry_status'] = 'Статус';

// Error
$_['error_permission'] = 'Предупреждение: У вас нет прав для изменения модуля Meest Express!';
