<?php

// Text
$_['text_title'] = 'Meest Express';
$_['text_description'] = 'Доставка Meest Express';
$_['text_title_warehouse'] = 'Отделение';
$_['text_title_postomat'] = 'Почтомат';
$_['text_title_courier'] = 'Курьер';
$_['error_not_enabled'] = 'Доставка Meest Express не включена';
$_['error_api_credentials'] = 'API учетные данные Meest Express не настроены';

// Text
$_['text_title'] = 'Meest Express';
$_['text_description'] = 'Доставка Meest Express';
$_['text_title_warehouse'] = 'Отделение';
$_['text_title_postomat'] = 'Почтомат';
$_['text_title_courier'] = 'Курьер';
$_['text_country'] = 'Страна';
$_['text_region_state'] = 'Регион/Область';
$_['text_city'] = 'Город';
$_['text_address'] = 'Адрес';
$_['text_address_input'] = 'Ввод адреса';
$_['text_address_input_placeholder'] = 'Введите адрес';
$_['text_address_details'] = 'Детали адреса (дом, квартира)';
$_['text_address_placeholder'] = 'Улица, дом, квартира';
$_['text_warehouse'] = 'Отделение';
$_['text_postomat'] = 'Почтомат';
$_['text_street'] = 'Улица';
$_['text_select'] = 'Выберите';
$_['text_no_results'] = 'Ничего не найдено';
$_['text_searching'] = 'Поиск...';
$_['text_fill_required_fields'] = 'Заполните все обязательные поля.';
$_['error_not_enabled'] = 'Доставка Meest Express не включена';
$_['error_api_credentials'] = 'API учетные данные Meest Express не настроены';
