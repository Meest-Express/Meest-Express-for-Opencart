<?php

// Text
$_['text_title'] = 'Meest Express';
$_['text_description'] = 'Доставка Meest Express';
$_['text_title_warehouse'] = 'Відділення';
$_['text_title_postomat'] = 'Поштомат';
$_['text_title_courier'] = 'Кур\'єр';
$_['error_not_enabled'] = 'Доставка Meest Express не увімкнена';
$_['error_api_credentials'] = 'API облікові дані Meest Express не налаштовані';

// Text
$_['text_title'] = 'Meest Express';
$_['text_description'] = 'Доставка Meest Express';
$_['text_title_warehouse'] = 'Відділення';
$_['text_title_postomat'] = 'Поштомат';
$_['text_title_courier'] = 'Кур\'єр';
$_['text_country'] = 'Країна';
$_['text_region_state'] = 'Регіон/Область';
$_['text_city'] = 'Місто';
$_['text_address'] = 'Адреса';
$_['text_address_input'] = 'Введення адреси';
$_['text_address_input_placeholder'] = 'Введіть адресу';
$_['text_address_details'] = 'Деталі адреси (будинок, квартира)';
$_['text_address_placeholder'] = 'Вулиця, будинок, квартира';
$_['text_warehouse'] = 'Відділення';
$_['text_postomat'] = 'Поштомат';
$_['text_street'] = 'Вулиця';
$_['text_select'] = 'Оберіть';
$_['text_no_results'] = 'Нічого не знайдено';
$_['text_searching'] = 'Пошук...';
$_['text_fill_required_fields'] = 'Заповніть усі обов\'язкові поля.';
$_['error_not_enabled'] = 'Доставка Meest Express не увімкнена';
$_['error_api_credentials'] = 'API облікові дані Meest Express не налаштовані';
